#정부 브리핑 (국토부)

import urllib.request
import bs4

 
endpoint = "http://www.korea.kr/news/pressReleaseList.do?"   

date= "2020-03-09"

newsId=""
pageIndex="1"
repCodeType="A"
repCode="A00006"
startDate= date
endDate= date
srchWord=""




paramset = "newsId="+"&"+"pageIndex="+ pageIndex + "&" +"repCodeType="+repCodeType +"&" + "repCode=" +repCode + "&" + "startDate="+startDate + "&" + "endDate="+endDate+ "&"+ "&srchWord="+srchWord 




url = endpoint + paramset
html  = urllib.request.urlopen(url)

bs_obj = bs4.BeautifulSoup(html, "html.parser")
list_type = bs_obj.find("div",{"class":"list-type"})
lis = list_type.findAll("li")



print(url)
print("")
print("")
print("")

for li in lis:
    dt = li.find("dt")
    print(dt.text)

    
#정부 브리핑 (기재부)

import urllib.request
import bs4

 
endpoint = "http://www.korea.kr/news/pressReleaseList.do?"   


newsId=""
pageIndex="1"
repCodeType="A"
repCode="A00007"
startDate= date
endDate= date
srchWord=""




paramset = "newsId="+"&"+"pageIndex="+ pageIndex + "&" +"repCodeType="+repCodeType +"&" + "repCode=" +repCode + "&" + "startDate="+startDate + "&" + "endDate="+endDate+ "&"+ "&srchWord="+srchWord 




url = endpoint + paramset
html  = urllib.request.urlopen(url)

bs_obj = bs4.BeautifulSoup(html, "html.parser")
list_type = bs_obj.find("div",{"class":"list-type"})
lis = list_type.findAll("li")


print("")
print("")
print(url)
print("")
print("")
print("")

for li in lis:
    dt = li.find("dt")
    print(dt.text)