
#부동산 헤드라인 

import urllib.request
import bs4

 
endpoint = "https://land.naver.com/news/headline.nhn"   

date= "20200309"
    
paramset =  "?"+ "bss_ymd=" + date 

url = endpoint + paramset
html  = urllib.request.urlopen(url)

bs_obj = bs4.BeautifulSoup(html, "html.parser")
news_area = bs_obj.find("div",{"class":"news_area"})
lis = news_area.findAll("dt")


print("")
print("")
print("")
print(date,"부동산 헤드라인")

for dt in lis:
    print("")
    print(dt.text)
    

    
#부동산 가장 많이 본 뉴스(주간)

import urllib.request
import bs4

 
endpoint = "https://land.naver.com/news/best.nhn?best_tp_cd="   


weekly = "WW"

paramset =  weekly

url = endpoint + paramset
html  = urllib.request.urlopen(url)

bs_obj = bs4.BeautifulSoup(html, "html.parser")
view_on = bs_obj.find("div",{"class":"view_on"})
lis = view_on.findAll("dt")


print("")
print("")
print("")
print(date,"(주간)부동산 가장 많이 본 뉴스")

for dt in lis[0:10]:
    print(dt.text)
    
    

    
#일일 개발정보

import urllib.request
import bs4

 
endpoint = "https://land.naver.com/news/field.nhn?news_type_cd=30"   

    
paramset =  "&"+ "bss_ymd=" + date 

url = endpoint + paramset
html  = urllib.request.urlopen(url)

bs_obj = bs4.BeautifulSoup(html, "html.parser")
section_headline = bs_obj.find("div",{"class":"section_headline"})
lis = section_headline.findAll("dt")



print("")
print("")
print("")
print(date,"일일 개발정보")
print("")

for dt in lis:
    print(dt.text)
    
    


    

#핫이슈

import urllib.request
import bs4

 
endpoint = "https://land.naver.com/news/hotIssue.nhn"   


url = endpoint 
html  = urllib.request.urlopen(url)

bs_obj = bs4.BeautifulSoup(html, "html.parser")
list_rank = bs_obj.find("ol",{"class":"list_rank"})
lis = list_rank .findAll("li")



print("")
print("")
print("")
print(date,"핫이슈")
print("")
print("")

for a in lis:
    strong = a.find("strong")
    print(strong.text)