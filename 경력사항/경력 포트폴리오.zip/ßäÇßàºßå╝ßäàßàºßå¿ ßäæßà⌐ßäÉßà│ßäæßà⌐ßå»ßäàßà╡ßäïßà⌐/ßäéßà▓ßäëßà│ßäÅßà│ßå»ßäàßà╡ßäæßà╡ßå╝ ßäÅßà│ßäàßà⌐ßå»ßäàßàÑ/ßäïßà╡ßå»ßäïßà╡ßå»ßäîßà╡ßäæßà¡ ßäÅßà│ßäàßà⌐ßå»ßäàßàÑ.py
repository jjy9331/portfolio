#일일지표(KOSPI_1)

import pandas as pd
import requests


endpoint = "https://finance.naver.com/sise/sise_index_day.nhn?code="

index = "KOSPI"
page="1"

paramset = index + "&"+"page="+page

fs_url = endpoint + paramset
fs_page = requests.get(fs_url)
fs_tables = pd.read_html(fs_page.text)


temp_df = fs_tables[0]
#행 → 열 ↓ / [0] 첫번째 열 빼기
temp_df = temp_df.set_index('날짜')
#인덱스를 '날짜'를 기준으로 쓰겠다
temp_df = temp_df[['체결가','거래량(천주)','거래대금(백만)']]
#'체결가','거래량(천주)','거래대금(백만)'만 칼럼에 남기겠다.
temp_df = temp_df.loc[temp_df.index.dropna()]
# 행에 있는 NaN 값 없는 것은 빼겠다.

print(fs_url)
print("")
print("KOSPI 일별시세")
print("")
print(temp_df)



#일일지표(KOSPI_2)

import pandas as pd



endpoint = "https://finance.naver.com/sise/sise_index_day.nhn?code="

index = "KOSPI"
page="2"

paramset = index + "&"+"page="+page

fs_url = endpoint + paramset
fs_page = requests.get(fs_url)
fs_tables = pd.read_html(fs_page.text)
temp_df = temp_df.loc[temp_df.index.dropna()]



temp_df = fs_tables[0]
temp_df = temp_df.set_index('날짜')
temp_df = temp_df[['체결가','거래량(천주)','거래대금(백만)']]
temp_df = temp_df.loc[temp_df.index.dropna()]

print(temp_df)



#일일지표(KOSDAQ_1)

import pandas as pd



endpoint = "https://finance.naver.com/sise/sise_index_day.nhn?code="

index = "KOSDAQ"
page="1"

paramset = index + "&"+"page="+page

fs_url = endpoint + paramset
fs_page = requests.get(fs_url)
fs_tables = pd.read_html(fs_page.text)


temp_df = fs_tables[0]
#행 → 열 ↓ / [0] 첫번째 열 빼기
temp_df = temp_df.set_index('날짜')
#인덱스를 '날짜'를 기준으로 쓰겠다
temp_df = temp_df[['체결가','거래량(천주)','거래대금(백만)']]
#'체결가','거래량(천주)','거래대금(백만)'만 칼럼에 남기겠다.
temp_df = temp_df.loc[temp_df.index.dropna()]
# 행에 있는 NaN 값 없는 것은 빼겠다.

print("")
print("")
print(fs_url)
print("")
print("KOSDAQ 일별시세")
print("")
print(temp_df)



#일일지표(KOSDAQ_2)

import pandas as pd



endpoint = "https://finance.naver.com/sise/sise_index_day.nhn?code="

index = "KOSDAQ"
page="2"

paramset = index + "&"+"page="+page

fs_url = endpoint + paramset
fs_page = requests.get(fs_url)
fs_tables = pd.read_html(fs_page.text)
temp_df = temp_df.loc[temp_df.index.dropna()]



temp_df = fs_tables[0]
temp_df = temp_df.set_index('날짜')
temp_df = temp_df[['체결가','거래량(천주)','거래대금(백만)']]
temp_df = temp_df.loc[temp_df.index.dropna()]

print(temp_df)


#일일지표(환율_1)

import pandas as pd



endpoint = "https://finance.naver.com/marketindex/exchangeDailyQuote.nhn?marketindexCd=FX_"

index = "USDKRW"
page="1"

paramset = index + "&"+"page="+page

fs_url = endpoint + paramset
fs_page = requests.get(fs_url)
fs_tables = pd.read_html(fs_page.text)
temp_df = temp_df.loc[temp_df.index.dropna()]



temp_df = fs_tables[0]
temp_df = temp_df.set_index('날짜')
temp_df = temp_df[['매매기준율']]
temp_df = temp_df.loc[temp_df.index.dropna()]


print("")
print("")
print(fs_url)
print("")
print("환율 일별시세")
print("")
print(temp_df)


#일일지표(유가_WTI_1)

import pandas as pd



endpoint = "https://finance.naver.com/marketindex/worldDailyQuote.nhn?marketindexCd=OIL_"

index = "CL&fdtc=2"
page="1"

paramset = index + "&"+"page="+page

fs_url = endpoint + paramset
fs_page = requests.get(fs_url)
fs_tables = pd.read_html(fs_page.text)
temp_df = temp_df.loc[temp_df.index.dropna()]



temp_df = fs_tables[0]
temp_df = temp_df.set_index('날짜')
temp_df = temp_df[['파실 때']]
temp_df = temp_df.loc[temp_df.index.dropna()]


print("")
print("")
print(fs_url)
print("")
print("유가_WTI 일별시세")
print("")
print(temp_df)

#일일지표(국채3년_1)

import pandas as pd



endpoint = "https://finance.naver.com/marketindex/interestDailyQuote.nhn?marketindexCd=IRR_"

index = "GOVT03Y"
page="1"

paramset = index + "&"+"page="+page

fs_url = endpoint + paramset
fs_page = requests.get(fs_url)
fs_tables = pd.read_html(fs_page.text)
temp_df = temp_df.loc[temp_df.index.dropna()]



temp_df = fs_tables[0]
temp_df = temp_df.set_index('날짜')
temp_df = temp_df[['파실 때']]
temp_df = temp_df.loc[temp_df.index.dropna()]


print("")
print("")
print(fs_url)
print("")
print("국채3년 일별시세")
print("")
print(temp_df)


#일일지표(회사채3년_1)

import pandas as pd



endpoint = "https://finance.naver.com/marketindex/interestDailyQuote.nhn?marketindexCd=IRR_"

index = "CORP03Y"
page="1"

paramset = index + "&"+"page="+page

fs_url = endpoint + paramset
fs_page = requests.get(fs_url)
fs_tables = pd.read_html(fs_page.text)
temp_df = temp_df.loc[temp_df.index.dropna()]



temp_df = fs_tables[0]
temp_df = temp_df.set_index('날짜')
temp_df = temp_df[['파실 때']]
temp_df = temp_df.loc[temp_df.index.dropna()]


print("")
print("")
print(fs_url)
print("")
print("회사채3년 일별시세")
print("")
print(temp_df)



