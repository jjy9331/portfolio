#매경

import urllib.request
import bs4

 
endpoint = "https://news.naver.com/main/list.nhn?mode=LPOD&mid=sec"   

date= "20200309"
oid= "009"
    
paramset = "&"+"oid=" + oid + "&"+ "date=" + date

url = endpoint + paramset
html  = urllib.request.urlopen(url)

bs_obj = bs4.BeautifulSoup(html, "html.parser")

type13 = bs_obj.find("ul",{"class":"type13"})
lis = type13.findAll("a",{"class":"nclicks(cnt_papaerart)"})


print(date,"주요지 헤드라인")
print("")
print("")

    
#신문제목
writing =type13.find("span",{"class":"writing"})

print(writing.text)

#주요헤드라인
    
for a in lis[0:2]:
    print(a.text)
    
print("")
print("")
print("")

#한경

endpoint = "https://news.naver.com/main/list.nhn?mode=LPOD&mid=sec"       
oid= "015"

paramset = "&"+"oid=" + oid + "&"+ "date=" + date

url = endpoint + paramset
html  = urllib.request.urlopen(url)

bs_obj = bs4.BeautifulSoup(html, "html.parser")

type13 = bs_obj.find("ul",{"class":"type13"})
lis = type13.findAll("a",{"class":"nclicks(cnt_papaerart)"})
    
#신문제목
writing =type13.find("span",{"class":"writing"})

print(writing.text)

#주요헤드라인
    
for a in lis[0:3]:
    print(a.text)
    
print("")
print("")
print("")


    
#조선

endpoint = "https://news.naver.com/main/list.nhn?mode=LPOD&mid=sec"       
oid= "023"

paramset = "&"+"oid=" + oid + "&"+ "date=" + date

url = endpoint + paramset
html  = urllib.request.urlopen(url)

bs_obj = bs4.BeautifulSoup(html, "html.parser")

type13 = bs_obj.find("ul",{"class":"type13"})
lis = type13.findAll("a",{"class":"nclicks(cnt_papaerart)"})
    
#신문제목
writing =type13.find("span",{"class":"writing"})

print(writing.text)

#주요헤드라인
    
for a in lis[0:3]:
    print(a.text)
    
    
print("")
print("")
print("")

 
    
    
    
    
#중앙

endpoint = "https://news.naver.com/main/list.nhn?mode=LPOD&mid=sec"       
oid= "025"

paramset = "&"+"oid=" + oid + "&"+ "date=" + date

url = endpoint + paramset
html  = urllib.request.urlopen(url)

bs_obj = bs4.BeautifulSoup(html, "html.parser")

type13 = bs_obj.find("ul",{"class":"type13"})
lis = type13.findAll("a",{"class":"nclicks(cnt_papaerart)"})
    
#신문제목
writing =type13.find("span",{"class":"writing"})

print(writing.text)

#주요헤드라인
    
for a in lis[0:1]:
    print(a.text)


print("")
print("")
print("")




#동아

endpoint = "https://news.naver.com/main/list.nhn?mode=LPOD&mid=sec"       
oid= "020"

paramset = "&"+"oid=" + oid + "&"+ "date=" + date

url = endpoint + paramset
html  = urllib.request.urlopen(url)

bs_obj = bs4.BeautifulSoup(html, "html.parser")

type13 = bs_obj.find("ul",{"class":"type13"})
lis = type13.findAll("a",{"class":"nclicks(cnt_papaerart)"})
    
#신문제목
writing =type13.find("span",{"class":"writing"})

print(writing.text)

#주요헤드라인
    
for a in lis[0:2]:
    print(a.text)
    
print("")
print("")
print("")


    
    
#한겨례

endpoint = "https://news.naver.com/main/list.nhn?mode=LPOD&mid=sec"       
oid= "028"

paramset = "&"+"oid=" + oid + "&"+ "date=" + date

url = endpoint + paramset
html  = urllib.request.urlopen(url)

bs_obj = bs4.BeautifulSoup(html, "html.parser")

type13 = bs_obj.find("ul",{"class":"type13"})
lis = type13.findAll("a",{"class":"nclicks(cnt_papaerart)"})
    
#신문제목
writing =type13.find("span",{"class":"writing"})

print(writing.text)

#주요헤드라인
    
for a in lis[0:3]:
    print(a.text)
    






